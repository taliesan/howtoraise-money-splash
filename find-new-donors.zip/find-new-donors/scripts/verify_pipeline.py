#!/usr/bin/env python3
"""Deterministic quality gates for a find-new-donors pipeline CSV.

Usage: python verify_pipeline.py <pipeline.csv> [--min-rows N] [--ledger ledger.md]
Default volume floor is 40 rows (full runs target 50-100). Test-scale runs
may pass --min-rows 20; every other gate applies at full strength.
With --ledger, any ledger line not terminated DONE / DRY / DESCOPED-BY-USER
is a FAIL: shipping with open lines is forbidden, and disclosing them in
Known Gaps does not close them.
Exits 1 if any gate FAILs. These checks exist because prompt-level rules
get violated under drift; code does not drift. Fix every FAIL before delivery.
Expected headers: see references/workbook-spec.md (companion CSV).
"""
import csv, sys, re, unicodedata
from collections import Counter

MARQUEE_MAX_PCT = 6      # <=~5% target, 6 allows rounding on small sheets
INDIVIDUAL_MIN_PCT = 55  # >=60% target with tolerance
DEEP_CHANNEL_MIN_PCT = 35   # % of Circle-3 rows found beyond donor-roll/gala
AGRADE_INDIV_MIN_PCT = 50   # % of A-grade rows that must be people/family vehicles
SURFACE_CHANNELS = {"donor-roll", "gala", "annual-report", "supporter-page"}
BRIEF_FLOOR_PCT = 12        # briefs >= max(10, 12% of rows)
URL_RE = re.compile(r"(https?://|\w+\.(org|com|edu|gov|io|net))")
DOC_RE = re.compile(r"(annual report|\bAR ?20\d\d|990|filing|press|gala|report to donors|\.pdf|donor (tier|page|list)|grantmakers|guidestar|propublica|patronview|newswire)", re.I)

def norm(s):
    s = unicodedata.normalize("NFKD", s.lower())
    s = re.sub(r"\b(the|foundation|fund|inc|charitable|trust|family)\b", "", s)
    return re.sub(r"[^a-z0-9]", "", s)

def main(path, min_rows=40):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    if not rows:
        print("FAIL: empty file"); return 1
    fails, warns = [], []
    c3 = [r for r in rows if str(r.get("circle","3")).strip() in ("3","Circle 3")]

    # 1. Volume
    if not (min_rows <= len(rows) <= 150):
        (fails if len(rows) < min_rows else warns).append(f"volume: {len(rows)} rows (floor {min_rows}, target 50-100)")

    # 2. Duplicates (normalized fuzzy-ish)
    seen = Counter(norm(r["participant"]) for r in rows)
    dupes = [k for k,v in seen.items() if v > 1 and k]
    if dupes: fails.append(f"duplicates after normalization: {len(dupes)} ({dupes[:5]})")

    # 3. Source evidence on every Circle-3 row
    unsourced = [r["participant"] for r in c3 if not (URL_RE.search(r.get("evidence_source","")) or DOC_RE.search(r.get("evidence_source","")))]
    if unsourced: fails.append(f"{len(unsourced)} Circle-3 rows lack a recognizable source ({unsourced[:5]})")

    # 4. Composition: individuals over institutions.
    # record_type values this gate recognizes as a PERSON: individual, couple, household,
    # family, family foundation / family_foundation. "family office" counts as institutional.
    # Everything else (foundation, trust, pooled fund, corporate, etc.) counts as institutional.
    # Emit these exact strings from consolidation — the gate keys on them and cannot guess.
    def is_person(rt):
        rt = rt.lower()
        if "family office" in rt: return False   # institutional-adjacent
        return any(t in rt for t in ("individual","couple","family foundation","family_foundation","household","family"))
    ind = sum(1 for r in c3 if is_person(r.get("record_type","")))
    pct = 100*ind/max(1,len(c3))
    if pct < INDIVIDUAL_MIN_PCT: fails.append(f"individuals/couples/family = {pct:.0f}% of Circle 3 (floor {INDIVIDUAL_MIN_PCT}%)")

    # 5. Marquee cap (flag-based: rows whose flags/notes mark MARQUEE)
    marquee = [r["participant"] for r in rows if "marquee" in (r.get("flags","")+r.get("notes","")).lower()]
    if 100*len(marquee)/len(rows) > MARQUEE_MAX_PCT:
        fails.append(f"marquee names {len(marquee)} exceed {MARQUEE_MAX_PCT}% cap")
    unrationalized = [m for m in marquee]  # every marquee needs rationale text near the flag
    # (rationale check is textual: the flag line must contain more than the word 'marquee')
    thin = [r["participant"] for r in rows if "marquee" in (r.get("flags","")+r.get("notes","")).lower()
            and len((r.get("flags","")+r.get("notes",""))) < 30]
    if thin: warns.append(f"marquee rows with thin rationale: {thin}")

    # 6. Grade distribution non-flat
    grades = Counter(r.get("quality_grade","").strip().upper() for r in c3)
    if len([g for g in ("A","B","C") if grades.get(g,0)>0]) < 3:
        fails.append(f"grade distribution flat/missing: {dict(grades)}")

    # 7. Interest-field swap-test heuristic: no two Circle-3 alignment texts near-identical
    texts = [(r["participant"], norm(r.get("interest_alignment",""))[:120]) for r in c3]
    tseen = Counter(t for _,t in texts if t)
    generic = [p for p,t in texts if t and tseen[t] > 1]
    if generic: fails.append(f"interchangeable Interest fields: {generic[:6]}")
    short = [p for p,t in texts if len(t) < 60]
    if short: warns.append(f"{len(short)} Circle-3 Interest fields are thin (<~1 sentence): {short[:5]}")

    # 8. Probability sanity: all Leads within 0-15
    bad_prob = [r["participant"] for r in rows if r.get("stage","Lead")=="Lead"
                and r.get("probability_pct") and not (0 <= float(r["probability_pct"]) <= 15)]
    if bad_prob: fails.append(f"Lead rows outside 0-15% band: {bad_prob[:5]}")

    # 9. Enrichment completeness: every row with a why_now must have all six-field siblings
    briefs = 0
    for r in rows:
        if r.get("why_now_trigger","").strip():
            briefs += 1
            missing = [f for f in ("risk_positioning","engagement_tone","capacity_evidence") if not r.get(f,"").strip()]
            if missing: fails.append(f"partial enrichment on {r['participant']}: missing {missing}")

    # 10. Brief floor: a thin brief layer means Phase 6 under-graded or Phase 5 under-flipped
    floor = max(10, round(BRIEF_FLOOR_PCT * len(rows) / 100))
    if min_rows >= 40 and briefs < floor:
        fails.append(f"only {briefs} tactical briefs (floor {floor} for {len(rows)} rows)")

    # 11. Depth gate: names found beyond the surface channels (the flip/hop-3/threads/sweeps).
    # Blank or "unknown" channels count as SURFACE (conservative): channels are recorded at
    # discovery time, never inferred retroactively — an unrecoverable channel cannot buy depth.
    if any(r.get("discovery_channel","").strip() for r in rows):
        deep = sum(1 for r in c3 if r.get("discovery_channel","").strip().lower() not in SURFACE_CHANNELS | {"", "unknown"})
        dpct = 100*deep/max(1,len(c3))
        if dpct < DEEP_CHANNEL_MIN_PCT:
            fails.append(f"only {dpct:.0f}% of Circle-3 rows discovered beyond donor-rolls/galas (floor {DEEP_CHANNEL_MIN_PCT}%) — the flip, hop-3, sweeps, and threads are underworked")
    else:
        fails.append("discovery_channel column empty/missing — depth is unmeasurable; record how every name was found")

    # 12. Anchor composition: an A-grade set of famous institutional funders is the
    # "I've seen this list before" failure — anchors must be mostly people/family vehicles
    a_rows = [r for r in c3 if r.get("quality_grade","").strip().upper() == "A"]
    if a_rows:
        a_ind = sum(1 for r in a_rows if is_person(r.get("record_type","")))
        apct = 100*a_ind/len(a_rows)
        if apct < AGRADE_INDIV_MIN_PCT:
            fails.append(f"A-grade rows only {apct:.0f}% individuals/family vehicles (floor {AGRADE_INDIV_MIN_PCT}%) — institutional brands are context rows, not anchors")

    print(f"Checked {len(rows)} rows ({len(c3)} Circle-3).")
    for f in fails: print("FAIL:", f)
    for w in warns: print("warn:", w)
    if not fails: print("ALL GATES PASS" + (f" ({len(warns)} warnings)" if warns else ""))
    return 1 if fails else 0

def check_ledger(path):
    """Every unit line must terminate DONE / DRY / DESCOPED-BY-USER (user quoted).

    Ledger format contract (see SKILL.md Phase 3): one line per unit, state edited IN PLACE
    on that line — never appended as a status paragraph elsewhere (append-style state makes
    the same unit read OPEN and DONE at once and defeats this check). Lines under a
    '## User decisions' or '## Exclusion universe' heading are records, not units — exempt.
    """
    open_lines, exempt = [], False
    for ln in open(path, encoding="utf-8"):
        ln = ln.strip()
        if ln.lower().startswith("## "):
            exempt = any(k in ln.lower() for k in ("user decision", "exclusion universe", "decisions on record"))
            continue
        if not ln or ln.startswith(("#", ">", "<!--")) or exempt: continue  # notes/comments/quotes are not units
        if re.search(r"\b(DONE|DRY|DESCOPED-BY-USER)\b", ln): continue
        if re.search(r"\bOPEN\b", ln) or re.search(r"\b(pending|TBD|not run|descoped for time|partial|remaining|incomplete)\b", ln, re.I):
            open_lines.append(ln[:90])
    if open_lines:
        print(f"FAIL: ledger has {len(open_lines)} open line(s) — shipping is forbidden until each is DONE, DRY, or DESCOPED-BY-USER:")
        for l in open_lines[:10]: print("   ", l)
        return 1
    print("ledger closed: every line terminated.")
    return 0

if __name__ == "__main__":
    args = sys.argv[1:]
    mr, ledger = 40, None
    if "--min-rows" in args:
        i = args.index("--min-rows"); mr = int(args[i+1]); del args[i:i+2]
    if "--ledger" in args:
        i = args.index("--ledger"); ledger = args[i+1]; del args[i:i+2]
    rc = main(args[0], mr)
    if ledger: rc = max(rc, check_ledger(ledger))
    sys.exit(rc)
