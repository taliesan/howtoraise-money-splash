#!/usr/bin/env python3
"""Canon-bleed scanner: greps EVERY cell of the finished Prospect Book for
internal research vocabulary that must never reach the reader.

Usage: python scan_book.py <book.xlsx>
Exits 1 on any hit. Expect occasional false positives (e.g. 'Hopkins' ~ 'hop',
'hopes'): the regex below word-bounds the risky short terms, but eyeball any
hit before rebuilding.
"""
import re, sys
from openpyxl import load_workbook

BANNED = re.compile(
    r"\b(circle ?[23]\b|hop [123]\b|hop-\d|flip\b|cross-connect|xconnect|deep cut"
    r"|marquee|grade [abc]\b|quality grade|probability|weighted|pass [12]\b"
    r"|desk research|tranche\b|ledger\b|node map|superseded|reinstated"
    r"|Lead 0|0-15%|XCONNECT|\[inference\]|\[verify\])",
    re.I,
)

def main(path):
    wb = load_workbook(path)
    hits = 0
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    m = BANNED.findall(c.value)
                    if m:
                        hits += 1
                        print(f"BLEED {ws.title}!{c.coordinate} {m} :: {c.value[:110]}")
    print("clean — zero canon-bleed hits" if not hits else f"{hits} hit(s) — fix and rebuild")
    return 1 if hits else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
