#!/usr/bin/env python3
"""Canon-bleed scanner: greps EVERY cell of the finished Prospect Book — or every
line of a PDF — for internal research vocabulary that must never reach the reader.

Usage: python scan_book.py <book.xlsx | book.pdf>
Scan THE EXACT FILE being shipped. If a PDF is delivered, scan the PDF, whatever
produced it — gates bound to one artifact format get silently bypassed the day a
run invents another. Exits 1 on any hit. Expect occasional false positives
(e.g. 'Hopkins' ~ 'hop', 'hopes'): eyeball hits before rebuilding.
Also flags STOCK phrases — a longish word-run recurring across entries. Composed-per-case
prose does not reuse sentences; a formula stamped across entries ("a resolved matter
needing no action beyond knowing it" x4) is the writing pass leaking a tic. Eyeball these:
a deliberate cover refrain can stay; a stamped entry formula gets recomposed per case.
"""
import re, sys, subprocess
from collections import Counter
from openpyxl import load_workbook

def _report_stock(pairs, where, hits):
    # Collapse overlapping 6-gram shingles into maximal repeated runs, one line per formula.
    counts = dict(pairs)
    shingles = set(counts)
    prefixes = {tuple(g.split()[:5]): g for g in shingles}
    suffixes = {tuple(g.split()[1:]) for g in shingles}
    continued = {g for g in shingles if tuple(g.split()[:5]) in suffixes}  # some shingle extends into g
    runs = []
    for start in shingles - continued:  # shingles no other shingle extends into
        words, n, cur = start.split(), counts[start], start
        while True:
            nxt = prefixes.get(tuple(cur.split()[1:]))
            if not nxt or nxt == cur: break
            words.append(nxt.split()[-1]); n = min(n, counts[nxt]); cur = nxt
        runs.append((" ".join(words), n))
    for g, n in sorted(runs, key=lambda x: -x[1])[:8]:
        hits += 1
        print(f"STOCK {where}: phrase recurs x{n}: '{g[:120]}' — composed prose doesn't reuse sentences; eyeball (refrain ok, stamped formula is not)")
    return hits

BANNED = re.compile(
    r"\b(circle ?[23]\b|hop [123]\b|hop-\d|flip\b|cross-connect|xconnect|deep cut"
    r"|marquee|grade [abc]\b|quality grade|probability|weighted|pass [12]\b"
    r"|desk research|tranche\b|ledger\b|node map|superseded|reinstated"
    r"|open ledger line|flip (pending|incomplete|required)|research unit"
    r"|Lead 0|0-15%|XCONNECT|\[inference\b|\[verify\b"
    # exemplar bleed: invented names/quotes from the skill's own teaching examples
    # (quality-cognition.md). These are fictional and must never appear in a real book —
    # BUT verify a hit isn't a real person who happens to share the surname before acting.
    r"|Corrigan|Whitmore|Aldrich Foundation|remembers at forty)",
    re.I,
)

# Unwritten-prose tells: enrichment field labels pasted into reader-facing text,
# and ALL-CAPS emphasis. These mean the Phase 8 writing pass was skipped.
LABELS = re.compile(r"\b(Why now|Why them|Approach|Path( in)?|Next|Capacity|Risk( & Positioning)?)\s*:"
                    r"|\b(SUGGESTED OPENING ASK|TIMING|SOURCES|CAPACITY|WHY THEM|WHY NOW|NEXT ACTION)\b")
SHOUT = re.compile(r"(?<![A-Z0-9./&-])[A-Z]{4,}(?:\s+[A-Z]{2,}){1,}(?![a-z])")  # multi-word caps runs
URLISH = re.compile(r"https?://\S+|\S+\.(org|com|edu|gov|net|io|ca|us|info)(/\S*)?", re.I)  # citations repeat legitimately — not stock prose

def scan_pdf(path):
    text = subprocess.run(["pdftotext", path, "-"], capture_output=True, text=True).stdout
    hits = 0
    from collections import Counter
    caps_lines = Counter()  # standalone-uppercase lines: a one-off is a section kicker
    for i, line in enumerate(text.split("\n"), 1):
        line = line.strip()
        if not line: continue
        if BANNED.findall(line):
            hits += 1; print(f"BLEED pdf:{i} {BANNED.findall(line)} :: {line[:100]}")
        if line == line.upper() and len(line) < 70 and re.search(r"[A-Z]{3,}", line):
            caps_lines[re.sub(r"[\d$,.].*$", "", line).strip()] += 1
            continue  # standalone caps line: judged by repetition below, not as shouting
        if LABELS.findall(line):
            hits += 1; print(f"UNWRITTEN pdf:{i} field labels {LABELS.findall(line)[:3]} :: {line[:90]}")
        sh = [s for s in SHOUT.findall(line) if s.strip() not in ("IRS", "EIN")]
        if sh:
            hits += 1; print(f"SHOUTING pdf:{i} {sh[:3]} :: {line[:90]}")
    pages = max(1, text.count("\f"))
    for cap, n in caps_lines.items():
        if n >= 3 and cap and abs(n - pages) > 2:  # kickers appear once or twice; running heads
            # repeat once per page; a FIELD LABEL repeats once per entry — that's the tell
            hits += 1; print(f"UNWRITTEN pdf: repeated field-label row '{cap}' x{n} — entries are labeled slots, not written prose")
    # Stock phrases: 6-word runs recurring in the prose. Lines that repeat ~once per page
    # (running heads/footers) are stripped from the stream first; remaining counts near the
    # page count are exempted too, same logic as the caps rows above.
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    lcount = Counter(lines)
    prose = URLISH.sub(" ", " ".join(l for l in lines if abs(lcount[l] - pages) > 2))
    words = re.findall(r"[a-z']+", prose.lower())
    grams = Counter(" ".join(words[i:i+6]) for i in range(max(0, len(words)-5)))
    stock = [(g,n) for g,n in grams.items() if n >= 3 and abs(n - pages) > 2]
    hits = _report_stock(stock, "pdf", hits)
    print("clean — zero canon-bleed hits" if not hits else f"{hits} hit(s) — fix and rebuild")
    return 1 if hits else 0

def main(path):
    if path.lower().endswith(".pdf"):
        return scan_pdf(path)
    wb = load_workbook(path)
    hits = 0
    prose_cells = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    m = BANNED.findall(c.value)
                    if m:
                        hits += 1
                        print(f"BLEED {ws.title}!{c.coordinate} {m} :: {c.value[:110]}")
                    if len(c.value) > 120:  # prose cells only
                        prose_cells.append(c.value)
                        lab = LABELS.findall(c.value)
                        if lab:
                            hits += 1
                            print(f"UNWRITTEN {ws.title}!{c.coordinate} field labels in prose {lab[:4]} :: {c.value[:90]}")
                        sh = [s for s in SHOUT.findall(c.value) if s.strip() not in ("IRS", "EIN")]
                        if sh:
                            hits += 1
                            print(f"SHOUTING {ws.title}!{c.coordinate} {sh[:3]} :: {c.value[:90]}")
    # Stock phrases across entries: a 6-word run appearing in 3+ distinct prose cells.
    presence = Counter()
    for cell in prose_cells:
        w = re.findall(r"[a-z']+", URLISH.sub(" ", cell).lower())
        for g in {" ".join(w[i:i+6]) for i in range(max(0, len(w)-5))}:
            presence[g] += 1
    hits = _report_stock([(g,n) for g,n in presence.items() if n >= 3], "xlsx", hits)
    print("clean — zero canon-bleed hits" if not hits else f"{hits} hit(s) — fix and rebuild")
    return 1 if hits else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
