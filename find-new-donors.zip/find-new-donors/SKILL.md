---
name: find-new-donors
description: "Build a donor prospect pipeline from scratch through exhaustive, verified desk research — 50-100 real, vetted funder names with integrated per-name analysis, delivered as a designed, print-ready Prospect Book plus a RaiseMoney-importable file. Use this skill whenever the user wants to find new donors, funders, or prospects: 'find me new donors', 'build a pipeline', 'who might fund us', 'we need more funders', 'prospect list', 'donor research', 'who should we be asking', 'populate my pipeline', 'find foundations for us' — even casual or partial phrasings. Trigger it for any request to discover funding sources the organization doesn't already know. Do NOT use it to deep-profile one already-known donor (that's prospect-research) or to import existing donor data (that's port-donor-data)."
---

# Find New Donors

You are about to run a **horsepower research operation**: three-hop desk research across hundreds of web pages, verified adversarially, enriched with tactical intelligence, and shipped as a document a consultant would charge for. The value of this skill is exhaustiveness — the output must dwarf what a graduate student could produce in months of uninterrupted research. Token spend IS quality here: never economize by narrowing the search. Never artificially stop early. Spend your full effort; complete every phase fully.

**The posture is a private investigator's, not a clerk's.** A clerk works the checklist, meets the floors, and goes home; a PI chases intuition into unusual places and keeps pulling threads — the co-trustee's surname, the company sale, the obituary, the foundation with no website — until each one either pays or demonstrably dies. The floors and the ledger below are the MINIMUM; they exist to catch the clerk, not to define the ceiling. When something smells interesting, that smell is a unit of work: write it into the ledger as a thread and chase it. The acceptance test is not "did the gates pass" — it is an insider looking at the list and asking *"how did you even find these people?"* A list whose strongest names are the funder brands every development director already knows has failed, even at 100 rows with every gate green.

Read `references/canon.md` before starting — it holds the doctrine this skill serves. The other references load per phase as noted.

## Phase 0 — The sermon, then serve

Open with this teaching, in your own words but keeping its spine (full version in canon.md):

> Discovery is not your problem. People new to fundraising think they need more names; the money actually stalls in the relationship — in ideas that arrived finished, in conversations that never got near power. Finding new funders is the LAST step of the craft, and learning to close matters more than any list. This skill will find you real people with real money and real reasons to care — and every one of them is a name, not a gift. Desk research is Source 1 of 5; your money will mostly come from conversations and encounters this list prepares you for.

Say it once, warmly, then get to work. Never block on it.

Then set expectations honestly: this run takes a long time (tens of minutes to more than an hour), fans out many research agents, and costs real compute. Promise — and deliver — **live narration**: report each discovery phase as it lands so this never feels like a magic box. Do not ask permission to visit websites; visiting hundreds of public pages is the job. Only pause for things that genuinely need the user (accounts, paywalls, strategy calls).

## Phase 1 — Ingest the organization (deep, then play it back)

Ask the user for their website URL and any documents that explain the organization and what they're raising for (case for support, campaign one-pager, annual report). Then research the org itself: fetch the site (all main pages), read every document, and search for outside coverage.

Produce an **organization profile** at real depth — not a summary. Structure: identity line (age, budget, staff, geography) · the work (programs, scale, evidence) · the logic (how they believe change happens) · the edges (tensions in the story) · current focus (campaign, amount, timeline, existing committed funders, gift table if any) · **funding lanes** — 3-5 distinct arguments for why different funder worlds would care, each naming example peer types. Multiple lanes is the point: one org lives in several funding worlds with different peers and donors.

**Play the profile back to the user and ask for corrections before spending compute on it.** A misread org poisons every downstream judgment. Identify any operating partners on the current campaign — their donor rolls will need partner-conflict handling.

**Then build the exclusion universe.** Ask for (or extract from RaiseMoney / their tracker) every funder the org already knows: current and lapsed donors, active conversations, prior research lists, event contacts. Record it in the ledger under its own heading. Every discovered name is deduped against it, and the book gets to make a real promise: "none of these were in your tracker when found." Names the user excludes for personal reasons (a board seat, a conflict) are DESCOPED-BY-USER with the reason quoted. Lapsed funders found in the universe are not discoveries, but flag them for the book's coaching — a renewal is easier than an introduction.

## Phase 2 — The peer orbit (checkpoint)

Propose ~10-12 peer organizations across all funding lanes. Screen for **donor-ecosystem richness**, not mission similarity: prefer orgs with published annual reports and donor tiers, galas/benefits with named chairs and sponsors, foundation grants, and $5M+ budgets funded by foundations and individuals. Deprioritize dues-funded, government-funded, or disclosure-free orgs — valid mission peers, useless research peers. If a candidate yields nothing when harvested, replace it mid-run; don't memorialize it.

Flag partner-orbit decisions explicitly (e.g., "your campaign partner's donor list is the most relevant list in existence AND mining it is a strategic call — include with flags, or exclude?").

**Present the orbit with one-line rationales and wait for the user's go.** This is the last checkpoint before the burn.

## Phase 3 — Write the ledger, then loop until dry

Before any harvesting, write a **hop ledger** file: one line per unit of work — every peer org, every source-type per peer, every funder to flip, every hop-3 org discovered later. Three terminal states only: **DONE** (evidence extracted, URL logged), **DRY** (≥3 distinct sources attempted, failure documented), or **DESCOPED-BY-USER** (the user explicitly called time on this line, quoted in the ledger). No fourth state exists. **Format contract (machine-checked):** the state lives ON the unit's line and is edited in place — never appended as a status paragraph elsewhere in the file, which leaves the same unit reading OPEN and DONE at once and defeats `verify_pipeline.py --ledger`. User decisions and the exclusion universe live under their own `## User decisions` / `## Exclusion universe` headings, which the checker exempts. **Synthesis is forbidden while any line is open, and so is shipping.** "Flip pending," "hop-3 not run," and "peers descoped for time" are open lines — disclosing them in Known Gaps does not close them. Known Gaps is for what the sources could not show, never for work the run chose not to do. If the session genuinely runs out of room, the run does not ask anything — it saves state per the checkpoint protocol below and ends with the resume instruction. Descoping happens only when the user raises it themselves.

**The thread rule (noticing):** every completed unit must log 0–3 *threads* — specific hunches the work surfaced but didn't chase (a surname recurring across two boards, an odd grantee, a fund that just closed, a widow who kept giving). Each thread becomes a ledger line like any other. A run whose units log zero threads everywhere is a clerk's run — treat that as a red flag on the unit prompts, not as clean work.

**The chase rule (pursuing):** a thread is worked as a *case with a question to solve*, not a search to run — see "The chase" in `references/source-playbooks.md`. The contract: every move in a chase must be generated by what the previous move revealed (the pivot rule); repeating the same kind of search is one move, not several. A chase exits DONE (question answered, sourced) or DRY (cold, with the move-chain logged — and a chain shorter than ~5 pivots is not cold, it's abandoned). The chases themselves cannot be playbooked — no two share a pattern — but the *triggers* that must open one can be, and the move-chain log makes a lazy pursuit visible to the critic after the fact.

The ledger is regenerated after every phase: each flip discovers new orgs, funders, and threads, which become new lines. **The run ends only when a regeneration pass adds zero new lines.** The user may interrupt at any point — that is their right, exercised unprompted — but the run NEVER asks whether to continue, never offers "keep going or call time?" as a menu, and never solicits the descope that would let it finish early. Continuing is not a decision; it is the default state of the run. The model's own sense of "enough" is not an exit condition, because that sense fires early — and neither is a politely offered off-ramp, because the run is the one offering it. That instinct is the enemy this skill exists to defeat.

**When a session genuinely runs out of room** (context exhaustion, platform limits — the only walls that count), the protocol is: update every ledger line in place, save all working files, and end with an instruction, not a question: "This run is not finished — N lines remain open. Say 'continue the donor run' and it resumes exactly here." Do NOT build the book at a checkpoint; a polished deliverable makes a half-done run look finished, which is how half-done runs get shipped. Build a progress artifact only if the user asks to see where things stand, and label it as mid-run in plain words.

## Phase 4 — Harvest (hop 1): peer donor rolls

For each peer org, one unit of work at a time (one agent per 1-2 peers if subagents are available — use a cheap/fast model for extraction, reserving stronger models for judgment). Load `references/source-playbooks.md` for per-source tactics. Floors per peer, checked against the ledger:

- **≥4 distinct source types attempted per peer**: annual report donor tiers, gala/benefit chairs-honorees-committees, 990 filings, press coverage of gifts, grant databases. A harvest with fewer is INCOMPLETE, not done.
- **Source-diversity floor for the run as a whole:** annual reports, galas, and 990s are the high-yield defaults and every run over-indexes on them unchecked. At least once per run, sweep the "beyond the ballroom" playbook channels — political-giving disclosures (FEC/OpenSecrets, as capacity evidence only), regional wealth/philanthropy lists (Crain's-class), a deliberate hidden-wealth-sector sweep, and adjacent trustee lists (hospitals, universities, community foundations) — and log each channel in the ledger as DONE or DRY like any other unit.
- **Donors only.** Staff, EDs, and honored artists are not prospects. Board members only with giving evidence or clear patron class, flagged as such.
- **Individuals over institutions.** A foundation on a thank-you page is EVIDENCE; the people behind it are the PROSPECT. Log both.
- **Every name carries the FULL source URL** you actually visited (verbatim page address, not just the domain), a source type, and the giving tier/amount when published. These URLs surface in the deliverable so the user can go read the evidence themselves.
- Search craft: short broad queries first, then narrow. Never guess URLs — fetch only URLs that appeared in search results or on fetched pages (provenance walls will kill guessed URLs). When a domain blocks fetching, climb the escalation ladder in the playbooks (press → archives → 990 mirrors → PDFs on other domains) BEFORE recording DRY. Asking the user is the last rung, not the second.

## Phase 5 — The flip (hop 2) and the bounce (hop 3)

This is where the deep cuts live — the names that make an insider ask "how did you even find these people?" For **every funder** hop 1 surfaced (mandatory, not selective):

- Open the 990/990-PF via ProPublica, grantmakers.io, CauseIQ, Instrumentl pages: extract **the people** (officers/trustees by name), assets, annual giving, and the **full grantee list**. A profile without the grantee list is half a hop.
- Identify the family: who are they, where's the wealth from, what else do they fund. The quiet foundation with no website is often a major principal in disguise — that unmasking is the single highest-value move in this skill.
- **Hop 3**: the funder's other grantees are new orbit orgs. Add their donor rolls to the ledger and harvest them. Repeat until regeneration runs dry.

## Phase 6 — Cross-reference, verify, grade

- **Cross-reference:** names appearing at 2+ peers independently are your strongest signals — and they clear partner-conflict flags. Dedupe by normalized name before anything downstream.
- **Adversarial verification (separate pass, non-negotiable):** collect every identity claim that came from your priors rather than a fetched page ("X = founder of Y firm", family relationships, "this foundation = that person") and set a verifier — prompted to REFUTE — on each. Verdicts: CONFIRMED (2+ independent sources) / REFUTED (correct the row) / UNRESOLVED (flag `[inference]`, never assert). This pass reliably catches wrong-firm, wrong-person, and dead-principal errors that would humiliate the user in a meeting. It also catches material events (deaths, successions, spend-downs) that change entire approach strategies.
- **Grade and structure** per canon.md: Circle (2 = connectors/validators, 3 = potential funders), letter grade A/B/C (fit + capacity + cross-connections — art not science), Stage = Lead, probability 5-15% (pessimistic), Amount = a defensible conversation size (revisited in Phase 7 with capacity evidence). Every row also records its **discovery_channel** — how the name was actually found: `donor-roll` (peer annual report/supporter page), `gala`, `990-flip` (unmasked from a filing), `hop-3` (found via a funder's other grantees), `press`, `board-adjacent`, `political-disclosure`, `regional-list`, `sector-sweep`, or `thread` (a chased hunch). This field is what makes depth measurable.
- **Composition gates** (enforced by `scripts/verify_pipeline.py`): ≥60% individuals/couples/family-foundations · ≤5% marquee celebrity names (each kept needs a stated precedent rationale) · grades non-flat · every Circle-3 row sourced · **depth gates:** ≥35% of Circle-3 rows discovered beyond the surface channels (not donor-roll/gala — the flip, hop-3, threads, and sweeps are where deep cuts live), and **≥50% of A-grade rows must be individuals, couples, or family vehicles** — an anchor set composed of famous institutional funders is the "I've seen this list before" failure in its purest form, no matter how well the briefs read. The professionalized philanthropies every insider already knows (the Audacious/Blue Meridian/McGovern class) may appear as B-grade context rows at most; they are not discoveries.
- **The Interest field is the delegation bar:** 2-4 bespoke sentences tying THIS name's documented behavior to THIS org's specifics. The swap test: if two rows' Interest text could be exchanged undetected, both fail — rewrite both. If the user wouldn't act on the field without redoing the research, the research wasn't done.

## Phase 7 — Enrich the anchors (Pass 2)

Every A-grade row (and B-grade on request) gets a full tactical brief — one agent per 1-2 names, fresh research required, using `references/enrichment-guide.md`. Floor: at least max(10, ~15% of rows) briefs on a full run; a thinner brief layer means Phase 6 under-graded or Phase 5 under-flipped — go back, don't ship thin. Six fields, each 2-4 sentences, each sourced:

1. **Why Them** — the sharpened alignment bridge.
2. **Why Now** — a REAL, DATED timing signal (liquidity event, board rotation, new initiative, campaign completion, succession). "No timing signal found: [what was checked]" is a legal answer; speculation is not.
3. **Risk & Positioning** — what turns them off, competing asks, how to differentiate.
4. **How to Walk In** — how they evaluate, what format, who speaks, plus a one-phrase tone calibration.
5. **Capacity (evidence)** — an ask bracket WITH its evidence: 990 payouts, published tiers, largest known gifts. Never a vibe.
6. Sensitivity rules apply: illness, bereavement, advanced age, live controversies get dignified handling and explicit approach guidance (holds, sequencing, board-tolerance decisions) — enrichment routinely surfaces deaths and diagnoses the filings don't show.

## Phase 8 — Write the book, then build it (and LOOK at it)

Load `references/workbook-spec.md` and the xlsx skill. The deliverable is a **Prospect Book the user reads**, not a sheet the user works — one cohesive document where each name's analysis sits with the name, closing with the invitation to bring the list into RaiseMoney. Two hard rules govern it:

- **The method is invisible.** None of this skill's internal vocabulary (circles, hops, grades, probabilities, stages, passes, ledger language, working flags) may appear anywhere in the book — the spec's "rule zero" has the full banned list and the plain-language section mapping. The reader experiences a book a senior consultant wrote.
- **The prose is written, not assembled.** All reader-facing copy comes from a dedicated writing pass: writer agents on a strong model, every batch given the SAME style brief verbatim (voice, banned vocabulary, sensitivity rules, facts discipline, length bands), outputs merged and validated mechanically. Spending extra tokens per entry to get fleshed-out natural sentences is required, not optional — compressed choppy copy is a shipped defect. Consistency across parallel API calls comes from the shared brief plus validation, never from hope.

Two more hard rules, learned from a live run:

- **A half-researched row never wears its to-do in the book.** A name whose flip or verification is still an open ledger line cannot be graded A, cannot appear in "Begin here," and its entry never says "flip pending" or "open ledger line" — either hold the row for the next edition or place it in a plain-language "Names we are still running down" section that says, in the house voice, what is known and that the trail is still being walked. The reader sees a book, never the machinery — ESPECIALLY when the machinery is mid-stroke.
- **Interim editions exist only on the user's request.** The run never builds the book while ledger lines are open on its own initiative — a polished mid-run PDF is how checkpoints get mistaken for deliverables. If the user asks to see where things stand, build the interim edition and say on the cover, plainly, that several trails are still being run and a fuller edition follows. discovery_channel is recorded at discovery time and never inferred retroactively — a row whose channel can't be recovered is labeled `unknown`, which the depth gate counts as surface. And within "Begin here," lead with the discoveries and renewals; the famous names the org could have found without you go below them, however good their dated theses are.

Then produce, in order:

1. **The writing pass** per the spec (batched writer agents → merged JSON → mechanical validation: coverage, length bands, banned-vocabulary regex).
2. **The book** — three tabs (Welcome cover · The Prospects with integrated cases and full source citations · Sources & Next Step), built per the spec's design system. Full source URLs per name; the analysis richer than the working notes, never thinner.
3. **The RaiseMoney-importable CSV** — the working mechanics (circles, grades, stages, probabilities, next actions) live HERE and only here, flat and ready for port-donor-data.
4. **Verify:** `scripts/scan_book.py` (zero canon-bleed hits across every cell) → recalc (zero errors) → soffice PDF → READ the PDF pages and fix what you see (the spec lists known gotchas). Ship the PDF alongside the book as the print preview. What the user prints must look like something they'd hand a board member.

## Phase 9 — The cold review (critique → patch → resubmit)

The gates catch what could be enumerated in advance; this phase catches what couldn't. Load `references/critique-loop.md` and run it in full: spawn a **fresh critic agent** (strong model, zero context from this run — give it the files, never a summary) armed with its four expertise sources per the reference (the canon verbatim, the failure museum, live research for every judgment that can be empirical — including the search-backed insider test — and clearly-labeled priors, which alone can never block). It performs the blind insider read of the book and then the rigor audit of the CSV, ledger, and gate output, returning a machine-readable punch list with a verdict of ship / patch / structural. Every blocking item becomes ledger lines with the critic's "done looks like" as the exit test; the run patches — it never argues (disputes are marked CONTESTED with evidence and go to the user). Re-run all deterministic gates, rebuild, and resubmit to the same critic with the patch log. Two rounds maximum; still-open blocking items after round two are a user decision, quoted in the ledger — never silently shipped over. The deliverable does not ship on any verdict except **ship**.

## Phase 10 — The audit, then the handoff

Before declaring victory, produce the **promised-vs-delivered audit**: every floor from this skill (ledger closed — zero lines open, descopes user-quoted? hop depth ≥3? ≥4 source types per peer? beyond-the-ballroom channels attempted? threads logged and chased? all A/B rows two-anchor sourced? volume 50-100? composition AND depth gates passed? brief floor met? verification run? canon-bleed scan clean? render checked? **cold review reached verdict "ship" — in how many rounds, with which contested items?**) — met / partial / missed. **Any "missed" or "partial" on ledger closure, depth gates, or verification blocks shipping** — go back and finish; those are not disclosure items. Underselling at the finish line is the failure mode this gate exists to catch; a run that narrates success while shipping "partly vetted" has failed even if the sheet is good.

Then the handoff coaching, briefly and in the sermon's voice: this sheet is Source 1. The names now need paths (Circle 2 coffees, "who else should we be talking to?" at the end of every meeting), the user should work the pipeline bottom-up (practice on C's before touching A's), and the top names deserve full persuasion profiles — offer the prospect-research skill for those, and port-donor-data to load everything into RaiseMoney.

## Operating rules (all phases)

- **One unit of work per loop.** "Find my next donor," repeated, beats "find 50 donors" — depth scales with how narrow the ask is. Fan out for breadth; never widen a single unit.
- **Parallelize independent fetches** aggressively; serialize only dependent steps.
- **Persistence:** never stop a phase because output is "probably enough." Floors and the ledger decide, not felt sufficiency. If context runs long, save state to the ledger and working files, then continue — the files are the memory. **Stopping is never the run's proposal:** only two things end a run — a regeneration pass that adds zero lines, or the user interrupting on their own initiative. "Should I keep going?" is a forbidden question in every phase.
- **No invention, ever.** Every claim is sourced or flagged `[inference]`. An empty field beats a plausible one.
- **Legal posture:** you are doing the user's own research on public pages — reading, not scraping at scale. Respect blocks; route around via other public sources; never bypass auth or paywalls.
- **Degraded mode:** no subagents available → run the same units inline, batched; same floors, same ledger, same exits. Slower is acceptable; shallower is not.
