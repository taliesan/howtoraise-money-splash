# The Prospect Book — deliverable spec

The deliverable is a **book the user reads**, not a sheet the user works. Working the names —
stages, probabilities, next actions, notes — happens in RaiseMoney; the book exists to introduce
the prospects, make the case for each, show the evidence, and end with the invitation to import
the list. Build with openpyxl per the xlsx skill's rules (Arial, recalc clean). Three tabs that
render as one continuous document when printed.

## Rule zero: the method is invisible

Internal research vocabulary must NEVER appear anywhere in the book — not in headers, section
titles, cell text, names, or notes. Banned outright: Circle 2/3, hop, flip, cross-connect,
XCONNECT, deep cut, marquee, grade A/B/C, Lead (as a stage), probability, weighted, Pass 1/2,
desk research, tranche, pipeline (as jargon), ledger, harvest, node, and status suffixes leaked
from working data (SUPERSEDED, REINSTATED, HOLD as a label). The reader should experience a
prospect book a senior consultant wrote, with no idea a protocol produced it. Internal buckets
map to plain-language sections:

| internal              | user-facing section                    |
|-----------------------|----------------------------------------|
| enriched anchors      | "Begin here — the strongest cases"     |
| A/B, not enriched     | "The strong field"                     |
| C                     | "Further prospects"                    |
| Circle 2 (connectors) | "People who open doors" (no ask figures — say plainly they are door-openers, not gift prospects) |

Sensitive holds (a bereavement, an illness) are expressed inside the entry's prose, with dignity
and a plain recommendation ("we recommend waiting until 2027..."), never as a flag or column.

## The house design system (mandatory — this is the brand, not a suggestion)

The book ships in the RaiseMoney family's paper theme. Do not adapt colors to the client's
brand, do not invent tokens, do not add fills, boxes, or shadows anywhere. The look is: black
words on white paper, one gold accent used sparingly, hairline rules doing all the structure.

**Tokens (paper theme):**
plum `0A0C22` (headings, titles, prospect names) · ink-mid `3A3A52` (all body/case text) ·
ink-faint `6B6880` (metadata: who-they-are, sources, footers, intros) · gold-deep `C68920`
(kickers, eyebrows, ask numerals, the one accent rule — display only, never body text) ·
hairline `D9D8E1` (every rule) · plum-card `F6F5F8` (the only permitted fill, panels only) ·
white background everywhere else.

**Fonts:** Arvo (slab serif) for everything bold — titles, section heads, prospect names, ask
numerals; never below ~9pt and never for body copy. Jost Light for all body and metadata text;
Jost SemiBold for kickers and column headers. The clean rule for openpyxl: bold → Arvo,
regular → Jost Light, kickers/headers → Jost SemiBold, explicitly.

**Getting the fonts onto the machine** (LibreOffice embeds installed system fonts): `npm
install @fontsource/arvo @fontsource/jost`, convert the needed woff2 files to TTF with
fonttools (`TTFont(src); f.flavor=None; f.save(...)` — install fonttools+brotli via pip),
save into `~/.fonts/`, run `fc-cache -f`, and confirm with `fc-list` that "Arvo", "Jost
Light", and "Jost SemiBold" resolve (weights install as separate family names). Google's font
CDN is typically unreachable from sandboxes — the npm route is the reliable one. If fonts
genuinely cannot be installed, fall back to Georgia for Arvo and Arial for Jost and say so in
the audit; never ship the fallback silently.

## The writing pass (before any openpyxl)

All reader-facing prose is written by dedicated writer agents — a strong model, spending real
tokens per entry — never assembled from research-note fragments. Compressed, choppy,
telegraphic AI copy is a shipped defect equal to a broken formula.

Why this pass is architecturally separate (learned the hard way): the research agents are
explicitly told their output is machine-read raw data, so their fields arrive compressed BY
INSTRUCTION — semicolon chains, labels, dropped verbs. That register must never reach a reader.
Three rules follow. **The agent that found the facts never writes the book copy** — research
turns are loaded with searching, verifying, and extracting, and language gets whatever attention
is left, which is none. **Writers COMPOSE fresh from the facts; they never "clean up" the
compressed strings** — an agent asked to edit dense text anchors on it and the compression
survives; an agent asked to write the entry from the evidence produces sentences. **Batches
stay small** (~4 anchor entries or ~13 short ones per call) — prose quality decays through a
long output as the model rations tokens, which is why the bottom of an over-batched book
collapses into fragments first.

- Every writer receives the FULL organization profile — identity, thesis, programs, funding
  lanes — not a one-line campaign summary. This is not a nicety: a writer holding a rich funder
  dossier and a thin client sketch will write funder biography, because that's what it knows.
  The entry's spine is the intersection (see quality-cognition's "middle of the Venn diagram"),
  and the intersection needs both circles fully drawn. Each entry names at least one concrete
  thing the funder and the client could actually do together.
- Write ONE style brief file and give every writer batch the identical brief. Voice consistency
  across parallel API calls comes from the shared brief plus mechanical validation — never from
  hoping the batches sound alike. The brief specifies: voice (a senior development director
  briefing a smart board member — warm, precise, fleshed-out complete sentences, varied rhythm,
  no headline compression), the full banned-vocabulary list, sensitivity rules, a facts
  discipline clause (rephrase freely, add nothing: no new names, numbers, dates, or claims),
  and per-section length bands.
- Length bands: strongest cases 130–190 words in two paragraphs (weave together: why they belong,
  why this season, what to know before approaching, how they evaluate and what the first
  conversation should look like, what their record suggests about ask scale); strong field
  55–95 words; further prospects 40–65; door-openers 45–75 framed around which door they open.
- **Every entry contains the walk-in.** The case is only half done at "why them" — each entry
  names the actual way in: the person or relationship that opens the door, the setting, what to
  lead with. Where the honest answer is that no path exists, the entry says so and names the
  funder's own process ("no unsolicited proposals; the open application round is the only door").
  A book of forty cases and zero named paths has shipped half its column.
- **Sources are full URLs, deduplicated.** The citation column carries the verbatim page
  addresses from the research, each once — "example.org · example.org · example.org" is the
  tell of an unread citation list.
  Each entry also gets a one-line plain-language "who they are" (≤95 chars).
- Batch ~4 anchor entries or ~13 shorter entries per agent; each writes a JSON file keyed by
  exact name. After merging, validate mechanically: every name present, length bands respected,
  banned-vocabulary regex over every entry (expect false positives like "Hopkins"/"hopes" —
  check hits before acting), no brackets or ALL-CAPS flags.

## Tab 1 — Welcome (portrait cover, one page)

Letterspaced eyebrow (the org's name, gold-deep Jost SemiBold 10pt — spread the letters by hand
with spaces, since spreadsheets have no letter-spacing; this is the ONLY cell whose text may be
altered for display) · "New Donor Prospect Book" in Arvo bold plum, 26pt · subtitle line in
Jost Light (campaign · goal · prepared date) · a 3px gold-deep rule row. Then four short prose
sections written in the
house voice: **What this book is** (counts, total contemplated giving, "a horizon, not a
forecast") · **How the research was done** (plain language: whose donor rolls were read, that
foundations' IRS filings were pulled and their other grantees followed, that trails were run
until they stopped producing names, that identities were verified — no method jargon) ·
**A word before you begin** (the sermon in human voice: a name is not money; the distance is the
work; the research removes the excuse, not the work) · **When you finish reading** (italic: the
book is for reading and deciding; bring the list into RaiseMoney to work it). Counts and totals
are computed in the build script and written into the prose — the cover carries no live
formulas and no stat tiles; this is a document, not a dashboard.

## Tab 2 — The Prospects (the body)

Title row ("THE PROSPECTS", Arvo bold plum, no fill) + one header row (Jost SemiBold 9pt plum,
no fill, thin gold-deep rule as its bottom border; repeat both on every printed page via
print_title_rows). Five columns:
**Name** (bold, ~24) · **Who they are** (~30) · **First ask** (~13, `$#,##0`, blank for
door-openers) · **The case — and how to walk in** (~92, the integrated analysis) · **Where we
found them** (~42, full readable citations). No other columns: no health, next action, stage,
probability, close date, grade, or notes. Sections in the order of the mapping table, each with
a section kicker (MERGED across all columns, height ~22 — an unmerged band clips): gold-deep
Jost SemiBold uppercase over a hairline top rule, NO fill — sections are divided by rules, never
by colored bands — and a one-line italic intro in faint gray. Within a section, sort by ask
descending. No zebra striping: every row gets a thin hairline bottom border instead, and the
column treatments carry the hierarchy — names in Arvo bold plum, who-they-are and sources in
faint-gray Jost Light at 8.5–9pt, asks as right-aligned gold-deep Arvo bold numerals, the case
in Jost Light 10pt ink-mid. Dynamic row heights from text (`12.8 * lines + 6`, estimating
~103 chars/line in
the case column at width 92 — over-estimating strands half-empty pages, under-estimating clips).
Print: landscape, legal, fitToWidth=1 fitToHeight=0, narrow margins, footer "[Org] — New Donor
Prospect Book" + "Page &P of &N".

## Tab 3 — Sources & Next Step (portrait)

Three sections, label column + body column, dynamic heights:
1. **Where this research comes from** — every principal source as a full readable citation with
   its real URL (the annual report and where its PDF lives, the gala listing pages, the IRS
   filing mirrors with profile paths, the press outlets). This exists so the user can go read
   the sources themselves; partner-sourced material gets its sequencing caveat here too.
2. **What this research could not see** — honest, specific gaps in plain words, ending on the
   quiet giver no list catches.
3. **Your next step — bring this list into RaiseMoney** — the book's closing move and the only
   call to action: name the companion CSV file, say that importing it turns each name into a
   working relationship in RaiseMoney, and coach the first move (start with a few names from
   "Further prospects" — the early conversations are practice, and practice is what the
   strongest cases deserve).

## Source citations (the "Where we found them" column)

Full URLs are captured at harvest time (see source-playbooks.md) and carried through to this
column, humanized: "Public Art Fund supporter listing (publicartfund.org/support)" ·
"IRS Form 990-PF via Grantmakers.io (grantmakers.io/profiles/v0/…)". Transform compressed
research shorthand deterministically in the build script, not via agents (agents may invent
URLs). Gotcha: when splitting compound citations on "+", require spaces on BOTH sides
(`\s\+\s`) or "$1M+ tier" shears apart.

## Known gotchas (each cost a build cycle once)

1. fitToWidth is IGNORED unless `sheet.sheet_properties.pageSetUpPr =
   PageSetupProperties(fitToPage=True)` is set per sheet.
2. Fixed row heights clip wrapped text — compute heights from text length everywhere.
3. LibreOffice can't evaluate modern formulas — this book avoids live formulas entirely.
4. Merged cells: write the top-left anchor only. Section kickers must be merged.
6. Fonts must be installed BEFORE the soffice render (see the design system section) — a PDF
   rendered before `fc-cache` silently falls back to substitute faces. Check `pdffonts` output
   for embedded Arvo/Jost as part of render-verify.
5. Working-data name suffixes (— REINSTATED etc.) leak into display names — strip on write.

## Verification gates (all mandatory, in order)

1. **Canon-bleed scan**: `scripts/scan_book.py book.xlsx` — regex over EVERY cell of the
   finished workbook for the banned vocabulary. Zero hits or fix and rebuild.
2. `recalc.py` → zero errors; `soffice --headless --convert-to pdf`; **READ the PDF pages**
   (cover, first body page, a section transition, the sources page): clipped bands? spilled
   columns? half-empty rows? choppy prose that survived? Fix and re-render until clean. Ship
   the PDF alongside the xlsx as the print preview.
3. `scripts/verify_pipeline.py <csv>` on the companion CSV — every FAIL fixed before delivery.
   Volume floor 40 (full runs target 50-100); test runs may pass `--min-rows N`.

## Companion CSV (RaiseMoney import — where the mechanics live)

The working apparatus the book deliberately omits lives here, flat, one row per prospect:
participant, title_role, organization, record_type, circle, quality_grade, stage,
probability_pct, amount_usd, expected_close, interest_alignment, why_now_trigger,
risk_positioning, engagement_tone, capacity_evidence, connection_path, next_action,
evidence_source, discovery_channel, flags, health_last_touch. discovery_channel records
how the name was actually found (donor-roll, gala, 990-flip, hop-3, press, board-adjacent,
political-disclosure, regional-list, sector-sweep, thread) — the depth gates read it. Enrichment fields empty for non-enriched rows.
This is what port-donor-data ingests; it is a machine file and is allowed its internal
vocabulary.
