# The Canon — why this skill works the way it does

This skill implements Source 1 of the five places new donors come from. The doctrine below is the reasoning; the SKILL.md phases are its mechanics. Internalize it — the voice of the deliverable and of your coaching comes from here.

## The five sources (and where this skill sits)

New donors come from exactly five places: **(1) desk research** — this skill; **(2) the Study** — endless cups of coffee, each ending with "Who else should we be talking to?"; **(3) the intentional accidental encounter** — conferences, dinners, hallways, where the major-donor money actually arrives; **(4) your existing donor base** — a renewal is easier than an initiation; **(5) mergers & acquisitions** — be the shiny thing a bigger org takes to its donors.

The awkward, load-bearing truth: **the money mostly comes from Source 3, which cannot be scheduled.** You run the sources you CAN schedule — this one, and the Study — precisely so that when the user ends up next to the right person at the right dinner, they already know who that person is and are practiced enough to engage instantly. Desk research produces the map and the recognition; it does not produce gifts. Say so in the deliverable.

## What desk research is

Make a list of ~10 peer organizations. Mine each in three places: their website/annual report (the thank-you page — take those names), their 990 filings (ProPublica, grantmakers.io, Candid-adjacent mirrors), and their communications (events, grant announcements). Then **flip it**: look up each funder found, find the specific program that funded the peer, see who ELSE it funds, and mine those orgs' thank-you pages in turn. Bounce back and forth **until you're not getting any names**. What this produces is a node map of the field — who exists, who is central, which cliques fund together, who works with whom — so that when a name drops in conversation, the user knows who it is.

What it does NOT produce: paths to people, things to say, applications, or money.

## The sermon (deliver before serving)

People are overly focused on discovery. They believe their problem is getting in front of donors; it isn't. The money stalls in the relationship — in the idea that arrived finished and left the donor nothing to shape, in the conversation that never got near power. Discovery is nearly free now; a list of names is worth exactly what it costs. Skill is scarce, and it can be learned. This skill serves the demand honestly AND refuses to let the user conflate a list with progress: every name ships at Lead, 5-15%, and the deliverable says on its face that a name is not money.

## Known blind spot

Desk research catches the big and the published; it misses the hidden donor — the quiet heir who never appears on a list. The flip (hop 2/3) recovers some of them by unmasking anonymous-looking foundations; the Study recovers the rest. Say this in Known Gaps rather than pretending completeness.

## Quality bar: surprise over celebrity

The acceptance test: an insider reads the list and says **"How did you even find these people?"** If they say "I've seen this list before," the run failed. Deep cuts — quiet family foundations unmasked to their principals, second/third-generation wealth, out-of-state money that chose this lane deliberately, program officers with real discretion — are the value. Keep at most 1-3 marquee names, each ONLY when a specific precedent earns the slot (e.g., the institution whose own initiative IS the user's thesis), never for list-padding. Hidden wealth hides in unglamorous sectors: logistics, waste, aggregates, regional banks, dealerships, construction, timber, food distribution, insurance — when a board name comes from one of these, dig for the family foundation.

## Pipeline mechanics the deliverable must respect

- **Circles:** the sheet is "everyone I'm talking to," not "my funding." Circle 2 = advisors, connectors, validators — where most time goes and where access to Circle 3 comes from; expected gift $0 and that's fine. Circle 3 = potential funders.
- **Quality letter grade** measures the LEAD's fit+capacity, not conversation progress. Art, not science. Two jobs: prioritize time (practice on C's, save A's for when sharp) and gate risk.
- **Stage/probability:** every discovered name is a Lead, 0-15%. Bands: Lead 0-15 · Conversation 16-40 · Shaping 41-60 · Work 61-95 · Closing 96-99 · Closed 100. When in doubt, pessimistic — better pessimistic and wrong than optimistic and wrong.
- **Weighted amount** = amount × probability. The honest arithmetic — a big list weighting out to a small number — is itself the sermon; surface it on the cover.
- **The Interest field is the whole game.** If the user can't trust it, they'll re-read every funder's website themselves and the research was worthless. Bespoke, specific, sourced, actionable — per name, no exceptions.
- **Work bottom-up.** The deliverable's coaching must say it: C's before B's before A's; you need practice; the fastest way to money is not the most direct way to maybe-money.

## Partner-conflict doctrine

When the user's campaign has an operating partner, that partner's donor roll is simultaneously the most relevant list in existence and a political minefield. Default: harvest it, flag every partner-only-sourced row conspicuously, and clear the flag only when a name is independently sourced elsewhere. Sequencing with partner leadership is the user's strategic call — the sheet's job is to make the call visible, not to make it.

## Why the structure is strict (the failure history)

Prompt-level exhortation alone does not produce exhaustiveness — systems governed by caps-lock rules with no structural enforcement ship celebrity lists, staff-as-donors, duplicate rows, and flat scores while narrating success. What works: externalized state with binary exits (the ledger), numeric floors, one unit of work per loop, deterministic script gates, a separate adversarial verifier, and a promised-vs-delivered audit the run cannot skip. Research corroborates it: premature termination and weak verification are top-tier agent failure classes, prompt fixes alone move quality only marginally, and on research tasks token spend explains most of the performance variance. Horsepower is the product; the structure is what guarantees it gets spent.

A second failure shape emerged even WITH the harness, on a live run: the run met its volume floor at the low end, then shipped with the ledger still open — flips pending, hop-3 never run, four peers "descoped for time" — and disclosed all of it politely in Known Gaps as if disclosure closed the lines. Its eight anchors were the eight most famous venture-philanthropy brands in the sector: every gate green, and an insider would say "I've seen this list before." The lesson: gates that measure volume don't measure surprise, and Known Gaps can become a fig leaf for work the run chose not to do. Hence the depth gates (discovery-channel floor, A-grade individual floor), machine-checked ledger closure, and the thread rule. The deep cuts were never missing from the world — the trails to them were simply never walked, because the surface channels filled the quota first.
