# How to know it's good before the user sees it

The scripts in this skill encode failures that have already happened once. Passing them means
only that you haven't repeated history. This file is the other half: how to FIND what's wrong —
including failure modes nobody has enumerated yet — using your own judgment, before the user
ever looks. Read it before building the deliverables and again before submitting to the cold
critic. It is not a checklist. It is how to think.

## 1. Become the reader

When the book exists, render it and READ it — not scan it for banned words, read it — as the
person who paid for it: a board chair with twenty minutes, or a first-time founder who has
never done this. That reader asks four questions of every entry: Who is this? Why should I
care? What do I actually do? Says who? An entry that makes them do work to answer any of the
four is unfinished, whatever the gates say. Read a few entries aloud in your head; language
that was rationed rather than written is audible immediately. And notice your own hesitations:
every time something makes you pause — a claim that feels slightly off, a name you can't quite
place, an entry you skim because it's tiring — that hesitation is data. The failures this file
cannot list announce themselves as hesitations. Chase every one.

## 2. Judge against the best, not against the rules

The rules tell you what's forbidden. The standard is what excellent looks like. The best
entries this system has produced share five behaviors; hold every entry against them:

- **They are written from the middle of the Venn diagram.** The reader already knows their own
  organization, and a funder's biography is a phone call away — what they are buying is the
  OVERLAP: why this campaign, of all things, maps onto this funder's demonstrated logic; what
  the two could concretely build together (a named stretch of the project, a study, a program
  in their neighborhood, a challenge structured their way); what this org offers that the
  funder's existing grantees don't. Tombstone facts — who they are, what they've given — enter
  only in service of an intersection claim, never as the entry's center of gravity. Test each
  sentence: is this ABOUT them, or about them-and-us? An entry that's mostly about them is a
  profile, not a case.
- **They reason to their numbers.** Best-in-class: an ask sized between two named benchmarks —
  "their historic $345K to us and their current $1M+ to a peer in the same thesis area; $250K
  sits comfortably between." An amount with visible reasoning is advice; an amount alone is a
  guess wearing a suit.
- **They refuse the easy assumption.** "Knight funded us before" is a fact; "Knight is warm" is
  an assumption — the officers who made those grants are probably gone. The excellent entry
  spots the assumption inside its own case and replaces it with what's actually known.
- **They name the real door and the real first move.** A named person, a named setting, a named
  opening line of reasoning — "ask Shannon Farley to characterize their current East Africa
  appetite, and if it's warm, she makes the introduction." "Engage via their networks" is not
  a move; it's a shrug.
- **Their timing claim survives the last-year test.** Ask of every why-now: would this sentence
  have been equally true a year ago? "A localization funding wave" — yes, so it's not a
  why-now. "Quoted by name in the February 24 cohort announcement" — no, so it is. A dated
  event or an honest "we looked in these places and found no signal" are the only two
  acceptable answers; momentum-vibes dressed as signal are worse than the honest no.
- **They say what could make the case wrong.** The strongest entries argue against themselves
  once: "the honest read is that they won't move until there's 12-18 months of post-beta
  traction, which sets the clock." An entry with no falsifier hasn't been thought about hard.
- **They found where this person's story lives.** For some targets that's an interview or a
  gala photo caption; for the quiet foundation with no website it's the 990, read closely —
  the class of source doesn't matter, but the entry must read like someone went and found the
  vein for THIS target rather than filling fields from whatever was easiest to query. The
  universal boilerplate test, applicable to every sentence in every phase: if it could be
  moved to a different donor or a different org undetected, it is not analysis; delete it or
  earn it.

A worked pair — same facts, two registers. What the pipeline produced once:
> "SHOFCO $25-99K donors; Matt Chanoff on SHOFCO board; early-stage capital background."

What written looks like:
> "Lisa and Matt Chanoff give to SHOFCO at the $25-99K level, and Matt sits on its board — a
> family already writing five-figure checks for Kenyan community-led work, with early-stage
> investing behind them. The way in runs through the SHOFCO orbit they already trust; the case
> to make is that community intelligence is the layer their existing commitment is missing."

Same facts. One is a database row; the other tells the reader who, why, what to do, and on
what evidence. If you cannot make an entry do that, the research is thin — go back a phase;
don't ship the fragment.

## 3. Read the whole, not just the rows

Rows can each be fine while the book is broken. Step back and ask what the LIST says:

- **Who carries the weight?** Trace every "path in" to the human it depends on. If a third of
  the anchors route through two or three people, the book has a concentration risk it must
  name on its own pages — and those bridge relationships become the real first asks.
- **What's conspicuously missing?** Hold the org's story next to the list. A Nairobi-born org
  whose book contains no Kenyan wealth, a schools program with no education funders — the
  reader will notice the hole; notice it first.
- **How old is the ground under each cluster?** When several entries hang from one source, find
  its date. A decade-old grant story can anchor a lead — but the entry must reckon with the
  decade, not just cite it.
- **Would the insider be surprised?** Read just the names in "Begin here" and ask what a jaded
  sector fundraiser says. If it's "I know this list," the run's deepest machinery didn't reach
  the top of the book, whatever the composition gates report.
- **Does the book keep its own promises?** Whatever the cover claims — none in your tracker,
  every entry sourced, discoveries first — verify by reading, as the reader would.

## 4. Diagnose causes, not symptoms

When something reads wrong, do not fix the instance and move on — ask what PRODUCED it. A
defect that appears twice is a pipeline bug wearing two disguises. Compressed choppy entries
usually mean research fields shipped without the writing pass, or a writer given too much in
one turn: the fix is to re-run the pass properly, not to hand-polish cells. Interchangeable
entries mean the evidence was thin and the prose is papering over it: the fix is research, not
rewording. Identical timing language across four funders means one agent's phrasing habit got
stamped across a batch: the fix is the batch, not the four cells. Fix causes and regenerate;
patched symptoms come back.

## 5. Be your own paid skeptic before the critic is

Before the cold review, write — actually write, not mentally note — the harshest fair critique
of your own deliverable: the three things a demanding client would seize on within five
minutes. There are always at least three; every artifact this skill has ever produced had
them, and they were found by exactly this exercise. Then fix them. The cold critic exists to
catch what you can't see about your own work — don't spend its attention on what you could.

## 6. The gates are the floor, not the standard

Run every script, fix every FAIL — and then remember what a green board means: you have not
repeated a failure that already happened to someone else. The standard lives above that, in
the reader's experience and the insider's surprise, and it is guarded by the cognition in this
file, applied by you, before anyone else looks. When your judgment and a rule ever seem to
conflict, the answer is almost always that the rule marks a past failure you're about to
rediscover — but if you're certain the case is genuinely new, flag it to the user plainly
rather than silently obeying or silently overriding.
