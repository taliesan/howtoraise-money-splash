# The Cold Review — a critic loop the run cannot skip

Deterministic gates catch what could be enumerated in advance; they cannot catch the failure
nobody wrote a regex for. That job belongs to a **cold reviewer**: a separate agent with a fresh
context, no memory of the run, no stake in its choices, and a mandate to judge the finished work
the way the client's harshest advisor would. The run produces; the critic critiques; the critique
comes back as a punch list; the run patches and resubmits. The loop — not either half alone — is
the quality mechanism.

## Who the critic is — and where its expertise actually comes from

One agent, strong model, spawned AFTER the deliverables exist. It has never seen the run's
reasoning, its narration, or its self-audit — that blindness is the point and must be protected:
give it files, never a summary of the run. Its persona: a jaded development director with twenty
years in the sector, who has seen a hundred prospect lists and rejects most of them, doing a paid
red-team review. It is told explicitly: "You are not here to be encouraging. You are here to find
what would embarrass the fundraiser in a meeting and what a rigorous reviewer would refuse to
sign. Every finding must name specific rows, entries, or ledger lines — an unactionable critique
is a failed critique."

The critic also gets `references/quality-cognition.md` — the reasoning method, not just the
rubric: judge against the best entries, run the last-year test on every timing claim, trace
paths to the humans that carry them, diagnose causes rather than cataloguing symptoms. The
rubric below is its floor, not its ceiling; its most valuable findings will be ones no rubric
line names.

The persona sets the stance; it is not the expertise. The critic's authority comes from four
named sources, and its prompt must include all four:
1. **The canon** — give the critic `references/canon.md` verbatim. It judges against the
   doctrine (surprise over celebrity, the Interest-field delegation bar, individuals behind
   institutions, the quality bar), not against generic fundraising vibes. The canon is the
   distilled expertise of the practice this skill serves; the critic is its enforcement arm.
2. **The failure museum** — the canon's failure-history section gives it precedents to
   pattern-match: the open-ledger-as-Known-Gaps move, the brand-anchor list, the gala
   over-index. It is explicitly asked: "which of these known failure shapes is this run
   repeating?"
3. **Its own live research** — every judgment that CAN be empirical MUST be: the spot-checks,
   the re-verifications, and the insider test below are done with searches and fetches, cited
   like any research claim. A critique finding backed by a fetched page outranks any opinion.
4. **Model priors** — sector knowledge and taste. Legitimate for flagging smells, but a
   priors-only finding must be labeled as judgment, not evidence, and cannot be blocking on
   its own.

**The insider test is empirical, not aesthetic.** For each anchor and a sample of ~10 further
rows, the critic runs the obvious searches a competent development director would run in their
first hour ("[sector] top funders", "who funds [field]", the peer orgs' own funder pages, the
sector press's annual funding roundups). A name that appears in those first-hour results is
KNOWN — it fails the surprise test with the URL as evidence. A name that doesn't surface until
the critic digs is a discovery. The critique reports the known:discovered ratio with the
receipts, converting "I've seen this list before" from a vibe into a measurement.

## The two reads (in this order, same agent)

**Read 1 — the insider read (blind).** The critic gets ONLY the Prospect Book (PDF or xlsx) and
the org's one-paragraph context. Questions it must answer with named examples:
- The surprise test: which entries would an insider already have on a list? Which made you ask
  "how did they find this person?" What is the ratio, and does the "begin here" section lead
  with discoveries or with brands everyone knows?
- Would a board member ACT on these cases — is each entry specific enough to walk in on, or
  could its text be swapped onto another name undetected?
- Prose: choppy compressed AI voice? Internal jargon bleed? Sensitive matters (deaths, illness)
  handled with dignity AND strategy?
- What is conspicuously absent — a lane, a geography, a wealth type the org's story implies but
  the list lacks?

**Read 2 — the rigor audit (with the working files).** Now the critic gets the CSV, the hop
ledger, and the verify-script output. It must:
- Hunt for disguised open work: ledger lines closed as DRY that show fewer than 3 attempts;
  "descoped" without a user quote; Known Gaps entries that are actually unfinished units.
- Check the depth claims: does the discovery_channel distribution match what the book implies?
  Spot-check 5 flips — did each funder's grantee list actually produce downstream rows, or was
  the flip logged DONE after extracting officers only?
- Independently re-verify 5 load-bearing identity claims (the ones a meeting depends on) chosen
  by the critic, not the run.
- Spot-check 3 enrichment briefs: do the dated triggers check out at their cited sources?
- **Audit the chases by their chains, not their outcomes.** Pull 5 chase/thread lines from the
  ledger: does each DRY show a real pivot chain (each move generated by the last move's
  findings, lens switches when one is exhausted), or did it die after a couple of same-lens
  searches? An abandoned-but-labeled-DRY chase is a blocking finding. Separately: did the run's
  working files show chase TRIGGERS that never became ledger lines (the half-named guest, the
  invisible grantee, the generic foundation shrugged past)? Name them.

## The critique (machine-readable, or it didn't happen)

```json
{"verdict": "ship | patch | structural",
 "blocking":     [{"id": "B1", "finding": "...", "evidence": "named rows/lines/pages",
                   "done_looks_like": "the observable state that closes this item"}],
 "improvements": [{"id": "I1", "...": "..."}],
 "notes": ["..."]}
```
"structural" means the run's shape is wrong (e.g., anchors are all institutions in a no-gala
sector) and patching rows won't fix it — the affected phase re-runs, not the whole operation.
A first-pass critique with zero blocking items AND zero improvements is treated as a failed
critique (rubric unanswered), not a clean bill — send it back once with the rubric restated.

## The patch loop

1. Every blocking item and accepted improvement becomes ledger lines under `CRITIQUE ROUND N`,
   with the item's `done_looks_like` as the exit test. The thread rule applies to patch work too.
2. The run patches — it does NOT argue. If the run believes a finding is factually wrong, it
   marks the item CONTESTED with counter-evidence and moves on; contested items are decided by
   the user, never by the run quietly ignoring them.
3. After patching: re-run every deterministic gate (verify_pipeline with --ledger, scan_book,
   render-verify), rebuild the deliverables.
4. Resubmit to the SAME critic with the prior critique and a patch log ("B1: done — see rows
   X, Y; B3: CONTESTED — evidence attached"). The critic verifies fixes item by item and may
   add findings the patches exposed, then issues a new verdict.
5. **Cap: two critique rounds.** Still-blocking items after round two go to the user as a
   plain-language decision ("ship with these named defects, or authorize another round"),
   quoted in the ledger. Silent shipping over an open blocking item is forbidden — it is the
   same crime as shipping with an open ledger line.

## Degraded mode

No subagents available → the loop still runs, weaker: finish and SAVE the deliverables, then in
a deliberately fresh pass (new working context, files re-read from disk, rubric loaded verbatim)
perform both reads and write the same JSON before any patching. Self-critique against a written
rubric with named-row discipline beats no critique; say plainly in the audit that the review was
not cold.
