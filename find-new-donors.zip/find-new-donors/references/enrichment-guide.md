# Enrichment Guide — Pass 2: from a vetted name to meeting-prep intelligence

Pass 1 proves a name is real and belongs. Pass 2 explains it — the layer that turns a pipeline row into something a fundraiser can walk into a room with. Every A-grade row gets the full treatment; B-grades on request; C-grades get alignment + capacity only (they earn full treatment when promoted).

## The unit

One agent per 1-2 names, strong model, FRESH research required — recent news (last 24 months), interviews, gift announcements, board changes, filings. The evidence rules are absolute: every claim carries a source actually found this pass; timing signals are dated events; nothing is inherited from Pass 1 without re-confirmation if it's load-bearing. If two prospects' fields could be swapped, both are rewritten.

## The six fields (each 2-4 sentences, sourced)

**1. Why Them (alignment bridge).** The sharpened case tying THEIR documented behavior to THIS org's specifics — actual grants, named gifts, stated philosophies. Ban filler stems ("values-aligned", "passionate about") unless tied to a citation. The honest bridge sometimes runs through a side door (their fellowship program, not the capital campaign; the archive, not the park) — say which door.

**2. Why Now (decision trigger).** A real, dated event: liquidity/fund close, role transition, new initiative launched, gift cycle completing, succession, a public win in their portfolio, a policy moment in their vocabulary. **"No timing signal found: [checked X, Y, Z]" is a legal and respectable answer. Speculation is not.** The trigger is often the single most valuable sentence in the brief — it's also where enrichment catches material events (a death, a diagnosis, a spend-down) that reshape the whole approach.

**3. Risk & Positioning.** What could go wrong: what they're sensitive to, what competing asks they field (including the user's own partner org soliciting them first), where the user's ask is a NEW category for them vs an extension, reputational considerations the board must weigh, and false-positive traps (similarly named entities, stale titles). Then how to position against each.

**4. How to Walk In (engagement angle + tone).** How this person evaluates: data vs narrative vs peer recommendation; format (site walk, small dinner, dense packet to the gatekeeper); who should speak; what to bring; sequencing (who gets approached first in a household or family office). End with a one-phrase tone calibration — "founder-to-founder evidence broker, private not press", "disciplined co-trustees, zero celebrity framing", "peer field-builder, not supplicant". Type heuristics: finance principals → mechanism and metrics first; collectors → artist and object first, budget second; heritage donors → legacy chapter, never transaction; program-officer-mediated funds → dense vetted materials to the gatekeeper, vision register for the principal; evidence-philanthropists → the research design IS the pitch.

**5. Capacity (evidence).** An ask bracket WITH its evidence: foundation assets and payout from filings, published donor tiers, largest known gifts with dates, career-capacity anchors. Distinguish foundation capacity from personal capacity. Where no reliable figure exists, say capacity is evidenced behaviorally and size the ask from the giving record, not a guessed net worth. This field is what makes the Amount column defensible.

**6. Next Action.** One concrete move, consistent with everything above (often: which connector to map, which frame to build, or an explicit HOLD with conditions).

## Sensitivity rules (non-negotiable)

Illness, bereavement, and advanced age are handled with dignity and change the strategy, not just the wording: active mourning → HOLD with a dated re-entry condition; public illness → route to the healthier/more available principal, modest first ask, zero urgency language; advanced age → legacy framing, multi-year cadence, staff-mediated process respected. Live controversies (investigations, litigation) are surfaced as a board-tolerance decision with the press-treatment evidence, never buried and never editorialized. When a household has an expansive public figure and a quieter co-decision-maker, name who leads the approach and why.

## Verification interlock

Enrichment claims about identity and events feed the same adversarial verifier as Pass 1. Anything the brief hinges on (a death, a firm affiliation, a family relationship) needs two independent sources or an explicit single-source flag. The brief that ships a wrong identity is worse than no brief.
