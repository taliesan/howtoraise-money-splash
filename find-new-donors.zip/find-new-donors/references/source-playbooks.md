# Source Playbooks — where names hide and how to extract them

General craft first, then per-source tactics, then the escalation ladder for blocked sources.

## Search craft

- **Broad before narrow.** Start with short queries ("[org] annual report donors", "[org] gala"); evaluate what exists; then drill. Long hyper-specific first queries return nothing and waste iterations.
- **Provenance rule.** Fetch only URLs that appeared in search results or on pages you already fetched. Guessed/constructed URLs hit provenance walls and burn time. If you need a specific page, search FOR it first.
- **Source-quality heuristic.** Primary documents (the org's own PDF, the 990 itself, the foundation's grants page) beat aggregators; aggregators beat SEO content farms. Cite the best source you touched.
- **Capture the FULL URL, verbatim, at the moment of extraction** — the exact page address, not just the domain. The deliverable's "Where we found them" column and its Sources page exist so the user can go read the evidence themselves; a citation that can't be followed is half a citation. Shorthand ("CPC AR 2024") is fine in working notes only if the harvest log holds the real URL beside it.
- **Disambiguate ruthlessly.** Same-named foundations and people are common (multiple "Berry Charitable Foundation"s, "David Schwartz"es, Millennium Partners vs Millennium Management). Confirm identity via EIN, geography, officer overlap — and record the disambiguation so it isn't redone.

## Playbook: annual reports & donor tiers (highest yield per page)

Search "[org] annual report", "[org] annual report donors", "[org] report to donors filetype:pdf". Org-hosted PDF paths (assets subdomains, wp-content) often surface in results even when the site blocks crawling. Tier pages ($100,000+ · $50,000-99,999 · ...) are GOLD: names WITH capacity evidence. Extract every tier down to ~$10K; note the year. "Chairman's Circle"-style membership pages are the online sibling.

## Playbook: galas & benefits (where individuals surface)

Search "[org] gala [year]", "[org] benefit", "[org] honoree", "[org] spring/fall benefit chairs". Extract honorees, chairs, vice-chairs, committee, and sponsor tiers — with the confidence distinction: **verified-gift** (sponsor tier with level) > **gala-chair** (strong signal) > **committee/attendee** (weak; keep only with other evidence). Event pages are often JS shells that fetch empty — go to society/press coverage (WWD, Vogue, Cultured, Artnews, Guest of a Guest, local press), the org's OWN Flickr/Instagram (album titles and captions name honorees), and press releases. Honored artists/officials are honorees, not donors.

## Playbook: 990s and foundation flips (where the deep cuts live)

For any nonprofit: ProPublica Nonprofit Explorer (search the name, confirm EIN). For private foundations (990-PF), the filing lists officers AND every grant — the flip's raw material. Mirrors that render grantee lists when ProPublica's full-text view doesn't: grantmakers.io (profiles/v0/ or /v1/ + EIN-name — reach them via search), CauseIQ, Instrumentl 990 reports, Grantable, GrantStation (also records application policy: unsolicited-accepted vs invitation-only — ALWAYS capture this; it determines the entire approach strategy).

The flip, per funder: (1) people — every officer/trustee by name; (2) scale — assets, annual disbursements, grant count, median/max grant; (3) grantee list with amounts; (4) family identity — who ARE they (obituaries, firm bios, wedding announcements, alumni magazines answer this); (5) trajectory — giving accelerating, flat, or spending down (payout % vs assets over 2-3 filings; >8-10% sustained = possible spend-down = urgency signal).

## Playbook: press & named gifts

"[org] receives grant", "[org] gift", "[person] donates", "$[X] million gift [org]". Major gifts get coverage naming donor, amount, motivation. Named physical assets (garden zones, wings, centers, funds) encode donor+scale permanently — search "[org] named gift" and scan the org's map/venue pages. Business press covers the capacity side: exits, fund closes, successions, retirements — Pass-2 fuel.

## Playbook: when the field has no galas (institutional sectors)

Arts-and-parks orgs publish gala rolls full of individuals; global-development, human-rights,
and civic-tech orgs publish funder LOGOS — foundations. Run hop 1 naively in those sectors and
you get a directory of professionalized philanthropies every insider already knows: the
"I've-seen-this-list-before" failure at its purest. When the peer orbit is institutional-heavy,
the individuals are hiding somewhere else, and the run must go get them:

- **The field's own wealth lineage.** Trace who got RICH out of the client's own movement —
  companies that grew from the same technology or community (the founders, early employees, and
  acquirers), then hunt their personal giving. Money that came out of a field is nostalgic for it.
- **Peer boards over peer funder pages.** Institutional-sector nonprofits still put wealthy
  private individuals on their boards. The peer's trustee list, flipped person by person to
  family foundations, beats its funder page.
- **Early believers.** Whoever personally funded the field's founding moment is 10-20 years
  richer now. Find the field's origin story in the press of that era and mine the named backers.
- **Regional and diaspora wealth.** For any org with a geographic identity, the region's
  industrial/banking families and its diaspora's exit wealth (confirmed liquidity events, then
  giving signals) — read the region's own business press, not just Western sources.
- **Patrons of the commons.** For open-source/open-data orgs: the named individual benefactors
  of Wikimedia-class endowments, archive projects, and infrastructure foundations — published
  lists exist and almost never overlap with sector funder pages.

The institutional brands the naive harvest returns are not worthless — they are CONTEXT rows
(B-grade at most) and flip targets whose staff, trustees, and grantee lists point at people.
They are never the discoveries, and they are never the anchors.

## Playbook: beyond the ballroom (the under-used half of the arsenal)

Annual-report tiers, galas, and 990 flips are the highest-yield-per-page sources, and runs
naturally over-index on them. A complete run also sweeps the channels where money shows up
that never buys a gala table — attempt each and log the attempt in the ledger:

- **Political giving disclosures.** FEC individual-contribution search (fec.gov) and OpenSecrets
  donor lookup surface capacity and civic engagement for names that appear nowhere on donor
  rolls, and confirm identity/employer for ambiguous names. Giving to campaigns is public record;
  treat it as capacity evidence, never as an approach angle.
- **Regional wealth and philanthropy lists.** Crain's (and the local business journal in other
  metros) publishes largest-philanthropist, top-foundation, and notable-board lists; city
  magazines run society and giving coverage. These catch locally-huge, nationally-invisible money.
- **Hidden-wealth sector sweep.** Deliberately search the unglamorous-industry boards and family
  foundations in the org's region — logistics, waste, aggregates, regional banks, dealerships,
  construction, timber, food distribution, insurance. When a name surfaces from one of these,
  pull the family foundation immediately; this is where the "how did you even find them" names live.
- **Adjacent trustee lists.** Hospitals, universities, and community foundations in the same
  geography publish trustee rosters full of philanthropically-active families who never touch
  the arts circuit; harvest them as cross-reference fuel and flag no-giving-evidence honestly.
- **DAF-adjacent signals.** Gifts routed through Schwab/Fidelity/Vanguard Charitable or a
  community foundation on a grantee list mean a privacy-first giver — note the pattern; it
  changes the approach (quiet, relationship-led) more than the capacity math.

## Playbook: boards & adjacent trustee lists

Board pages are the START, never the finish: a harvest that returns only board members has failed. Use boards as cross-reference fuel — a trustee from a hidden-wealth sector gets their family foundation searched; a name on two relevant boards is a cross-connect. Flag "board member, no giving evidence" honestly.

## The chase (how a thread gets worked)

This is the skill's actual PI behavior, and it cannot be reduced to channels: it is solving a
small mystery by improvising each next move from what the last one revealed. Search-engine
comprehensiveness is not the point — the sixth face at the gala table is not going to rank for
any query you'd think to type. What can be systematized is (a) when a chase MUST open, (b) what
a legitimate move is, and (c) what closing a case requires.

**Triggers — any of these opens a chase (a ledger line with a question):** an unidentified or
half-identified person in event coverage or a photo caption ("...and guests" — who?); a funder
or grantee with no findable web presence; a generic-named foundation ("Brook", "Elmo") that
could be anyone; a donor who appears exactly once, nowhere else; two entities sharing an
address, officer, or registered agent; a maiden name or remarriage that might link two giving
records; a grantee list full of orgs nobody has heard of; a "Friends of X" or LLC where a person
should be. The list is open-ended — the real trigger is the itch of "wait, who IS that?" — but
none of the above may be shrugged past.

**The pivot rule — what counts as a move.** A move must USE information the previous move
produced: the photo caption gives a partial name → the partial name plus the event gives a
LinkedIn or firm bio → the firm bio gives a family foundation → the 990 gives co-trustees →
a co-trustee gives the next question. Six variations of the same query on the same engine are
ONE move. When one lens is exhausted, switch lenses, don't re-grind: press releases → none? →
conference agendas and transcripts (they name partners and sponsors) → podcast guest lists →
alumni magazines → wedding/obituary archives → state corporation and property records →
Flickr/Instagram captions from the event itself. No fixed order — the case dictates it.

**Exits.** DONE = the question is answered and sourced ("the sixth person is X, managing
partner at Y; their family fund gave $Z to two peers"). DRY = genuinely cold, with the
move-chain logged so a reviewer can see the pursuit: a chain of fewer than ~5 real pivots is
not cold, it is abandoned — reopen it. Either way the chain log survives into the working
files; chases are audited by the chain, not by the outcome — cold cases chased hard are good
work; warm cases dropped early are the failure.

Worked examples of the shape (illustrative, deliberately patternless): a gala photo shows six
at the honoree's table and coverage names five → chase the sixth → identity → day job →
giving vehicle. A foundation's grantees are all invisible orgs → the orgs' own press pages are
empty → conference transcripts where their EDs spoke name their "philanthropic partners" →
one partner is a person, not a brand → flip them. A donor thanked once in 2019 and never
again → the org's Flickr from that year → a caption pairs them with a spouse whose surname
matches a family office → the family office's other gifts date after a company sale → capacity
and timing, both sourced.

## Escalation ladder for blocked sources (machine before human)

When a fetch is blocked (robots, provenance, JS shell, 403): 1) press coverage of the same content; 2) the org's own PDFs on other paths/subdomains (search filetype:pdf); 3) 990 mirrors (above); 4) the org's social accounts (Flickr albums, Instagram captions); 5) Wayback Machine IF an archive link surfaces in search results; 6) search-result snippets themselves (quote what the snippet shows, cite accordingly). One failure mode the ladder cannot beat: content that exists only inside images (sponsor-logo walls, scanned donor pages with no text layer). That is a legitimate DRY — record it as "image-only content" rather than burning iterations; press coverage of the same event is usually the better path anyway. Only after the ladder is exhausted: record DRY with the attempts listed. Asking the user to go look is a last resort reserved for account-gated sources.

## Per-unit agent brief (template)

When fanning out, every research agent gets: a persona line — **a private investigator, not a list-compiler: chases intuition into unusual places, pulls every thread (a co-trustee's surname, a company sale, a wedding announcement, a foundation with no website) until it pays or demonstrably dies, does not go home early**, plus surprise-over-celebrity and individuals-behind-institutions; the client context (3-4 sentences: who the org is, the campaign, the lanes); ONE unit of work with explicit floors (source types to attempt, what DONE requires); the rules block (donors only, FULL source URL mandatory, no invention, provenance rule, DRY documentation); and a strict JSON output schema ending with `sources_used`, `threads_not_chased` (specific hunches for the ledger — the PI's most valuable output after the names themselves), and `gaps`. Cheap/fast model for extraction units; stronger model for judgment units (peer selection, verification, enrichment). Tell each agent its reply is machine-read raw data, not prose for a human.
